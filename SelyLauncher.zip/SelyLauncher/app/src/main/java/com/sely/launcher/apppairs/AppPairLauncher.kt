package com.sely.launcher.apppairs

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper

/**
 * Sely App Pairs — launching a saved pair.
 *
 * 🟡 Load-bearing honesty note: `Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT`
 * is real, public, documented API (added API 24) — but Android only
 * honors it when the launching context is already in a multi-window-
 * capable state (large-screen devices, foldables, or an existing split
 * session). There is no public API for a regular app, launcher
 * included, to force the system into split-screen from a cold tap on
 * Home. On most phones, tapping a pair here will simply open App A,
 * then App B on top of it fullscreen — exactly like opening two apps
 * one after another, because that's genuinely what the platform does
 * in that situation. On tablets/foldables, or if the device is already
 * in multi-window, this will generally produce a real side-by-side
 * split. This is stated in the UI (see AppPairsActivity) rather than
 * promised as guaranteed behavior.
 *
 * The one thing that DOES reliably put two arbitrary apps into split
 * screen on a normal phone is Android's own Recents (Overview) UI —
 * long-press an app's card there and choose "Split screen". No
 * third-party launcher can trigger that UI programmatically; Sely can
 * only point the user to it, which AppPairsActivity does.
 */
object AppPairLauncher {
    fun launch(context: Context, pair: AppPair) {
        val intentA = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
            component = ComponentName(pair.packageA, pair.activityA)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intentA)

        Handler(Looper.getMainLooper()).postDelayed({
            val intentB = Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
                component = ComponentName(pair.packageB, pair.activityB)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT
            }
            context.startActivity(intentB)
        }, 350)
    }
}
