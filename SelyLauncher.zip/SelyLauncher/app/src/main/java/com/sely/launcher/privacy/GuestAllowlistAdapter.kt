package com.sely.launcher.privacy

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.Switch
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.sely.launcher.AppInfo
import com.sely.launcher.R
import com.sely.launcher.theme.ThemeManager

class GuestAllowlistAdapter(
    private val context: Context,
    private val apps: List<AppInfo>
) : RecyclerView.Adapter<GuestAllowlistAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val icon: ImageView = view.findViewById(R.id.gameIcon)
        val label: TextView = view.findViewById(R.id.gameLabel)
        val toggle: Switch = view.findViewById(R.id.gameSwitch)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = LayoutInflater.from(context).inflate(R.layout.item_game_toggle, parent, false)
        return ViewHolder(v)
    }

    override fun getItemCount() = apps.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val app = apps[position]
        holder.icon.setImageDrawable(app.icon)
        holder.label.text = app.label
        holder.label.setTextColor(ThemeManager.textPrimary(context))
        holder.toggle.setOnCheckedChangeListener(null)
        holder.toggle.isChecked = GuestModeStore.getAllowlist(context).contains(app.packageName)
        holder.toggle.setOnCheckedChangeListener { _, checked ->
            GuestModeStore.setAllowed(context, app.packageName, checked)
        }
    }
}
