package com.sely.launcher.desktopmode

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.sely.launcher.AppInfo
import com.sely.launcher.R
import com.sely.launcher.theme.ThemeManager

/**
 * Separate from AppGridAdapter on purpose: that adapter always launches
 * via a plain startActivity on whatever display it's called from, with
 * no hook to redirect it. Desktop Mode specifically needs every launch
 * to explicitly target the external display (see DesktopHomeActivity),
 * so this is its own small adapter rather than bending AppGridAdapter's
 * shape to fit a case it wasn't built for.
 */
class DesktopAppAdapter(
    private val context: Context,
    private val apps: List<AppInfo>,
    private val onClick: (AppInfo) -> Unit
) : RecyclerView.Adapter<DesktopAppAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val icon: ImageView = view.findViewById(R.id.appIcon)
        val label: TextView = view.findViewById(R.id.appLabel)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = LayoutInflater.from(context).inflate(R.layout.item_app, parent, false)
        return ViewHolder(v)
    }

    override fun getItemCount() = apps.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val app = apps[position]
        holder.icon.setImageDrawable(app.icon)
        holder.label.text = app.label
        holder.label.setTextColor(ThemeManager.textPrimary(context))
        holder.itemView.setOnClickListener { onClick(app) }
    }
}
