package com.sely.launcher.network

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.sely.launcher.databinding.ActivityNetworkCenterBinding
import com.sely.launcher.theme.ThemeManager

/**
 * Sely Network Center (spec section 14).
 *
 * See NetworkStats's class doc for the 🟢/🟡/🔴 breakdown. This screen
 * is read-only status plus real deep-links — it deliberately doesn't
 * duplicate Control Center's quick toggles; this is the "tell me
 * what's actually going on with my connection" screen, Control Center
 * is the "flip things quickly" screen.
 */
class NetworkCenterActivity : AppCompatActivity() {

    private lateinit var binding: ActivityNetworkCenterBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNetworkCenterBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.backArrow.setOnClickListener { finish() }

        binding.wifiRow.setOnClickListener { startActivity(Intent(Settings.ACTION_WIFI_SETTINGS)) }
        binding.bluetoothRow.setOnClickListener { startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) }
        binding.airplaneRow.setOnClickListener { startActivity(Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS)) }
        binding.internetRow.setOnClickListener { startActivity(Intent(Settings.ACTION_DATA_ROAMING_SETTINGS)) }
        binding.hotspotRow.setOnClickListener {
            // 🔴 No reliable public API to read/set hotspot state (see
            // NetworkStats doc) — best-effort deep link, since the exact
            // action varies by OEM on older Android versions.
            try {
                startActivity(Intent("android.settings.WIFI_TETHER_SETTINGS"))
            } catch (e: Exception) {
                Toast.makeText(this, "Open Settings > Hotspot & tethering", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        applyTheme()
        render()
    }

    private fun applyTheme() {
        val textPrimary = ThemeManager.textPrimary(this)
        val textSecondary = ThemeManager.textSecondary(this)

        ThemeManager.applyScreenBackground(binding.networkRoot)
        binding.screenTitle.setTextColor(textPrimary)
        binding.connectionType.setTextColor(textPrimary)
        binding.connectionDetail.setTextColor(textSecondary)
        listOf(binding.wifiRow, binding.bluetoothRow, binding.hotspotRow, binding.airplaneRow, binding.internetRow)
            .forEach { it.setTextColor(textPrimary) }
    }

    private fun render() {
        val snapshot = NetworkStats.snapshot(this)

        binding.connectionType.text = snapshot.connectionType
        binding.connectionDetail.text = when {
            snapshot.connectionType == "Wi-Fi" && snapshot.wifiSsid != null ->
                "Connected to ${snapshot.wifiSsid}" + (snapshot.wifiLinkSpeedMbps?.let { " · $it Mbps" } ?: "")
            snapshot.connectionType == "Wi-Fi" ->
                "Connected · grant location access to show network name"
            snapshot.connectionType == "Mobile data" ->
                snapshot.carrierName ?: "Carrier unavailable"
            else -> "Check your connection"
        }

        binding.bluetoothRow.text = if (snapshot.bluetoothEnabled) {
            if (snapshot.pairedBluetoothDevices.isEmpty()) "Bluetooth on · no paired devices"
            else "Bluetooth on · ${snapshot.pairedBluetoothDevices.joinToString(", ")}"
        } else "Bluetooth off"

        binding.airplaneRow.text = if (snapshot.airplaneModeOn) "Airplane mode on" else "Airplane mode off"
    }
}
