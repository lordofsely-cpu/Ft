package com.sely.launcher.modes

import android.content.Context
import com.sely.launcher.performance.PerformanceMode
import com.sely.launcher.theme.ThemeManager
import org.json.JSONArray
import org.json.JSONObject

/**
 * Sely Modes (spec section 23).
 *
 * Each profile is a real, applyable bundle of settings this project has
 * already built genuine control over — not a cosmetic label:
 *  🟢 Accent color + dark/light (ThemeManager — applies instantly and
 *     visibly across every screen, as already wired since Theme Engine)
 *  🟢 Performance mode (PerformanceModeStore — real animation/rotation
 *     effects, see its own class doc)
 *  🟢 Do Not Disturb on/off (NotificationManager — same permission-gated
 *     toggle already used in Control Center and Game Mode)
 *
 * Deliberately NOT included per-mode: wallpaper, per-mode favorites, or
 * per-mode widget layouts. Those are real Android capabilities too, but
 * swapping them automatically on mode-switch is a meaningfully bigger
 * feature (safely snapshotting/restoring a wallpaper bitmap, re-laying-
 * out a widget grid) — a reasonable next increment rather than bundled
 * in at the same fidelity as the rest of this file.
 */
data class ModeProfile(
    val name: String,
    val accentColor: Int,
    val isDark: Boolean,
    val performanceMode: PerformanceMode,
    val dndOn: Boolean,
    val isBuiltIn: Boolean
)

object ModesStore {
    private const val PREFS = "sely_modes"
    private const val KEY_CUSTOM = "custom_profiles"

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** Real, sensible presets — each a genuine combination of the three real levers above. */
    fun builtIns(context: Context): List<ModeProfile> {
        val blue = context.getColor(com.sely.launcher.R.color.sely_accent_blue_preset)
        val neon = context.getColor(com.sely.launcher.R.color.sely_accent_neon)
        val purple = context.getColor(com.sely.launcher.R.color.sely_accent_purple_preset)
        return listOf(
            ModeProfile("Normal", blue, true, PerformanceMode.BALANCED, dndOn = false, isBuiltIn = true),
            ModeProfile("Gaming", neon, true, PerformanceMode.PERFORMANCE, dndOn = true, isBuiltIn = true),
            ModeProfile("Study", blue, false, PerformanceMode.BALANCED, dndOn = true, isBuiltIn = true),
            ModeProfile("Work", blue, false, PerformanceMode.BALANCED, dndOn = false, isBuiltIn = true),
            ModeProfile("Night", purple, true, PerformanceMode.BATTERY, dndOn = true, isBuiltIn = true),
            ModeProfile("Battery Saver", blue, true, PerformanceMode.BATTERY, dndOn = false, isBuiltIn = true)
        )
    }

    fun customProfiles(context: Context): List<ModeProfile> {
        val raw = prefs(context).getString(KEY_CUSTOM, "[]") ?: "[]"
        val array = JSONArray(raw)
        val list = mutableListOf<ModeProfile>()
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            list.add(
                ModeProfile(
                    name = obj.getString("name"),
                    accentColor = obj.getInt("accent"),
                    isDark = obj.getBoolean("dark"),
                    performanceMode = PerformanceMode.valueOf(obj.getString("perf")),
                    dndOn = obj.getBoolean("dnd"),
                    isBuiltIn = false
                )
            )
        }
        return list
    }

    fun saveCustom(context: Context, profile: ModeProfile) {
        val current = customProfiles(context).toMutableList()
        current.removeAll { it.name == profile.name }
        current.add(profile)
        persist(context, current)
    }

    fun deleteCustom(context: Context, name: String) {
        val current = customProfiles(context).filterNot { it.name == name }
        persist(context, current)
    }

    private fun persist(context: Context, list: List<ModeProfile>) {
        val array = JSONArray()
        list.forEach { p ->
            array.put(JSONObject().apply {
                put("name", p.name); put("accent", p.accentColor); put("dark", p.isDark)
                put("perf", p.performanceMode.name); put("dnd", p.dndOn)
            })
        }
        prefs(context).edit().putString(KEY_CUSTOM, array.toString()).apply()
    }

    /** Snapshots the current live, real settings into a new named profile. */
    fun snapshotCurrent(context: Context, name: String): ModeProfile {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
        val dndOn = nm.isNotificationPolicyAccessGranted &&
            nm.currentInterruptionFilter != android.app.NotificationManager.INTERRUPTION_FILTER_ALL
        return ModeProfile(
            name = name,
            accentColor = ThemeManager.accentColor(context),
            isDark = ThemeManager.isDark(context),
            performanceMode = com.sely.launcher.performance.PerformanceModeStore.getMode(context),
            dndOn = dndOn,
            isBuiltIn = false
        )
    }
}
