package com.sely.launcher.performance

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.sely.launcher.R
import com.sely.launcher.databinding.ActivityPerformanceBinding
import com.sely.launcher.theme.ThemeManager
import com.sely.launcher.wallpaper.WallpaperRotationStore
import com.sely.launcher.wallpaper.WallpaperRotationWorker
import java.util.concurrent.TimeUnit

/**
 * Sely Performance System (spec section 44) — see PerformanceMode's
 * class doc for exactly what each mode does and doesn't affect, and why.
 */
class PerformanceActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPerformanceBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPerformanceBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.backArrow.setOnClickListener { finish() }

        binding.batterySaverLink.setOnClickListener {
            startActivity(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS))
        }

        buildRows()
    }

    override fun onResume() {
        super.onResume()
        ThemeManager.applyScreenBackground(binding.performanceRoot)
        binding.screenTitle.setTextColor(ThemeManager.textPrimary(this))
        binding.scopeNote.setTextColor(ThemeManager.textSecondary(this))
        ThemeManager.applyGlass(binding.batterySaverLink)
        binding.batterySaverLink.setTextColor(ThemeManager.accentColor(this))
    }

    private fun buildRows() {
        binding.modeList.removeAllViews()
        val selected = PerformanceModeStore.getMode(this)
        val accent = ThemeManager.accentColor(this)
        val textPrimary = ThemeManager.textPrimary(this)
        val textSecondary = ThemeManager.textSecondary(this)

        PerformanceMode.values().forEach { mode ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundResource(R.drawable.bg_glass_card)
                setPadding(dp(16), dp(14), dp(16), dp(14))
                val params = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                params.bottomMargin = dp(10)
                layoutParams = params
            }
            val title = TextView(this).apply {
                text = if (mode == selected) "${mode.label}  ✓" else mode.label
                textSize = 15f
                setTextColor(if (mode == selected) accent else textPrimary)
            }
            val desc = TextView(this).apply {
                text = mode.description
                textSize = 12f
                setTextColor(textSecondary)
                setPadding(0, dp(4), 0, 0)
            }
            row.addView(title)
            row.addView(desc)
            row.setOnClickListener {
                PerformanceModeStore.setMode(this, mode)
                reapplyWallpaperRotationConstraint()
                buildRows()
            }
            binding.modeList.addView(row)
        }
    }

    /** If rotation is already running, re-enqueue with the current mode's real constraint. */
    private fun reapplyWallpaperRotationConstraint() {
        if (!WallpaperRotationStore.rotationEnabled(this)) return
        val constraints = Constraints.Builder()
            .setRequiresCharging(PerformanceModeStore.requireChargingForBackgroundWork(this))
            .build()
        val request = PeriodicWorkRequestBuilder<WallpaperRotationWorker>(24, TimeUnit.HOURS)
            .setConstraints(constraints)
            .build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "sely_wallpaper_rotation", ExistingPeriodicWorkPolicy.UPDATE, request
        )
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
