package com.sely.launcher.gamemode

import android.content.Context

/**
 * Sely Game Mode (spec section 22).
 *
 * 🔴 Stated plainly, per the spec's own requirement: "Do not claim to
 * increase CPU/GPU performance unless Android actually provides such
 * control" — no API does, so nothing here does either.
 *
 * 🟡 Also stated plainly: the spec's example ("Free Fire → Gaming
 * profile") implies automatically activating this mode when a chosen
 * game launches. Detecting "which app is currently in the foreground"
 * from a launcher needs either `PACKAGE_USAGE_STATS` (a special,
 * separately-granted permission) or an Accessibility Service (a much
 * heavier, more privacy-sensitive capability) — both are real options
 * but deliberately not bundled into a launcher's gaming dashboard here.
 * So Game Mode is opened manually rather than auto-triggered; this
 * store just remembers which installed apps the user has tagged as
 * games, ready for that auto-activation to be added as its own,
 * explicitly-consented next step.
 */
object GameModeStore {
    private const val PREFS = "sely_game_mode"
    private const val KEY_GAMES = "game_packages"

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun getGames(context: Context): Set<String> =
        prefs(context).getStringSet(KEY_GAMES, emptySet()) ?: emptySet()

    fun isGame(context: Context, packageName: String) = getGames(context).contains(packageName)

    fun setGame(context: Context, packageName: String, isGame: Boolean) {
        val current = getGames(context).toMutableSet()
        if (isGame) current.add(packageName) else current.remove(packageName)
        prefs(context).edit().putStringSet(KEY_GAMES, current).apply()
    }
}
