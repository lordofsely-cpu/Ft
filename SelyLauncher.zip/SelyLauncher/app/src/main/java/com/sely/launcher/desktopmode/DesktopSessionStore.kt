package com.sely.launcher.desktopmode

import android.content.Context

/**
 * Sely Desktop Mode (spec section 31) — see DesktopHomeActivity's class
 * doc for what's real here and what isn't. This just remembers which
 * apps have been opened on the external display this session, so the
 * desktop taskbar has something to show and switch between — a regular
 * app has no public API to query "which windows currently exist on
 * display N", so Sely tracks only what it itself launched there.
 */
object DesktopSessionStore {
    private const val PREFS = "sely_desktop_session"
    private const val KEY_APPS = "apps_opened"

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun getOpened(context: Context): List<Pair<String, String>> {
        val raw = prefs(context).getString(KEY_APPS, "") ?: ""
        if (raw.isBlank()) return emptyList()
        return raw.split(";;").map {
            val parts = it.split("|||")
            parts[0] to parts.getOrElse(1) { "" }
        }
    }

    fun recordOpened(context: Context, packageName: String, activityName: String) {
        val current = getOpened(context).toMutableList()
        current.removeAll { it.first == packageName }
        current.add(0, packageName to activityName)
        val raw = current.take(8).joinToString(";;") { "${it.first}|||${it.second}" }
        prefs(context).edit().putString(KEY_APPS, raw).apply()
    }

    fun clear(context: Context) {
        prefs(context).edit().remove(KEY_APPS).apply()
    }
}
