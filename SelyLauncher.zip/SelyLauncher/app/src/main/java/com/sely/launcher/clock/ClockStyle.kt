package com.sely.launcher.clock

import android.content.Context

/**
 * Sely Clock System (spec section 42).
 *
 * DIGITAL/MINIMAL/LARGE/VERTICAL all render with Android's own
 * `TextClock` widget (🟢 auto-updates itself off the real system clock,
 * no manual ticking needed, no risk of drifting from actual time) at
 * different text sizes/formats. ANALOG is a custom-drawn face (see
 * AnalogClockView) since Android's built-in AnalogClock has been
 * deprecated since API 23 with no non-deprecated replacement — the
 * custom view still reads real `Calendar` time each tick, it just
 * draws it rather than using the retired widget.
 */
enum class ClockStyle(val label: String) {
    DIGITAL("Digital"),
    LARGE("Large"),
    MINIMAL("Minimal"),
    VERTICAL("Vertical"),
    ANALOG("Analog")
}

object ClockPrefs {
    private const val PREFS = "sely_clock"
    private const val KEY_STYLE = "style"

    fun getStyle(context: Context): ClockStyle {
        val name = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_STYLE, ClockStyle.DIGITAL.name)
        return ClockStyle.values().firstOrNull { it.name == name } ?: ClockStyle.DIGITAL
    }

    fun setStyle(context: Context, style: ClockStyle) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_STYLE, style.name).apply()
    }
}
