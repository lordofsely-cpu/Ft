package com.sely.launcher.privacy

import android.app.AlertDialog
import android.content.Context
import android.text.InputType
import android.widget.EditText

object PinPrompt {
    fun show(context: Context, title: String = "Enter PIN", onSuccess: () -> Unit, onCancel: () -> Unit) {
        val input = EditText(context).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        }
        AlertDialog.Builder(context)
            .setTitle(title)
            .setView(input)
            .setCancelable(false)
            .setPositiveButton("Unlock") { _, _ ->
                if (PrivacyLockStore.verify(context, input.text?.toString().orEmpty())) onSuccess() else onCancel()
            }
            .setNegativeButton("Cancel") { _, _ -> onCancel() }
            .show()
    }
}
