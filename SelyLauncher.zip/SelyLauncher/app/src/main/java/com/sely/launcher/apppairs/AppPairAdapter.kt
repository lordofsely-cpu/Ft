package com.sely.launcher.apppairs

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.sely.launcher.AppRepository
import com.sely.launcher.R
import com.sely.launcher.theme.ThemeManager

class AppPairAdapter(
    private val context: Context,
    private val pairs: List<AppPair>,
    private val onLaunch: (AppPair) -> Unit,
    private val onDelete: (AppPair) -> Unit
) : RecyclerView.Adapter<AppPairAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val iconA: ImageView = view.findViewById(R.id.pairIconA)
        val iconB: ImageView = view.findViewById(R.id.pairIconB)
        val label: TextView = view.findViewById(R.id.pairLabel)
        val launch: TextView = view.findViewById(R.id.pairLaunch)
        val delete: TextView = view.findViewById(R.id.pairDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = LayoutInflater.from(context).inflate(R.layout.item_app_pair, parent, false)
        return ViewHolder(v)
    }

    override fun getItemCount() = pairs.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val pair = pairs[position]
        val appA = AppRepository.resolveApp(context, pair.packageA, pair.activityA)
        val appB = AppRepository.resolveApp(context, pair.packageB, pair.activityB)
        holder.iconA.setImageDrawable(appA?.icon)
        holder.iconB.setImageDrawable(appB?.icon)
        holder.label.text = pair.name
        holder.label.setTextColor(ThemeManager.textPrimary(context))
        holder.launch.setTextColor(ThemeManager.accentColor(context))
        holder.delete.setTextColor(ThemeManager.textSecondary(context))
        holder.launch.setOnClickListener { onLaunch(pair) }
        holder.delete.setOnClickListener { onDelete(pair) }
    }
}
