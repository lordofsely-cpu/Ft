package com.sely.launcher.privacy

import android.content.Context
import java.security.MessageDigest

/**
 * Sely Privacy Center (spec section 9) — "Launcher settings PIN".
 *
 * 🟢 Real, but scoped honestly: this PIN gates Sely's own Settings and
 * App Management screens (see SettingsActivity/AppManagementActivity's
 * onCreate) — it is a launcher-level lock, not a system security
 * boundary. Anyone can bypass it by installing a different launcher or
 * using Android's own Settings app directly; no third-party app can
 * prevent that. Stored as a SHA-256 hash, never the raw PIN.
 */
object PrivacyLockStore {
    private const val PREFS = "sely_privacy_lock"
    private const val KEY_HASH = "pin_hash"

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun hasPin(context: Context) = prefs(context).contains(KEY_HASH)

    fun setPin(context: Context, pin: String) {
        prefs(context).edit().putString(KEY_HASH, hash(pin)).apply()
    }

    fun clearPin(context: Context) {
        prefs(context).edit().remove(KEY_HASH).apply()
    }

    fun verify(context: Context, pin: String): Boolean {
        val stored = prefs(context).getString(KEY_HASH, null) ?: return false
        return stored == hash(pin)
    }

    private fun hash(pin: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(pin.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }
}
