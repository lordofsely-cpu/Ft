package com.sely.launcher.wallpaper

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import com.sely.launcher.screenshotstudio.BitmapBlur

/**
 * Sely Wallpaper System (spec section 43) — effect functions.
 *
 * Blur reuses BitmapBlur (built for Screenshot Studio) run across
 * overlapping tiles covering the whole image — same real pixel-level
 * box blur, just applied to the full wallpaper rather than a brush
 * stroke. Dim is a genuine alpha-blended black overlay baked into the
 * bitmap before it's handed to WallpaperManager, not a runtime view
 * effect (there's no "dim the current wallpaper" API — the only way to
 * dim a wallpaper is to darken the image itself before setting it).
 */
object WallpaperEffects {

    fun applyBlur(bitmap: Bitmap, strength: Int): Bitmap {
        if (strength <= 0) return bitmap
        val working = bitmap.copy(Bitmap.Config.ARGB_8888, true)
        val step = 60
        var y = 0
        while (y < working.height) {
            var x = 0
            while (x < working.width) {
                BitmapBlur.blurRegion(working, x, y, brushRadius = step, blurStrength = strength)
                x += step
            }
            y += step
        }
        return working
    }

    fun applyDim(bitmap: Bitmap, dimPercent: Int): Bitmap {
        if (dimPercent <= 0) return bitmap
        val output = bitmap.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(output)
        val alpha = (255 * (dimPercent / 100f)).toInt().coerceIn(0, 255)
        val paint = Paint().apply { color = Color.argb(alpha, 0, 0, 0) }
        canvas.drawRect(0f, 0f, output.width.toFloat(), output.height.toFloat(), paint)
        return output
    }
}
