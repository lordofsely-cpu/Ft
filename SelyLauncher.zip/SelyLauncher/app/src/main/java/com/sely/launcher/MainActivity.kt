package com.sely.launcher

import android.content.Intent
import android.os.Bundle
import android.view.MotionEvent
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.sely.launcher.controlcenter.ControlCenterActivity
import com.sely.launcher.databinding.ActivityMainBinding
import com.sely.launcher.drawer.AppDrawerActivity
import com.sely.launcher.notifications.NotificationCenterActivity
import com.sely.launcher.gesture.HomeGestureListener
import com.sely.launcher.gesture.EdgeGestureListener
import com.sely.launcher.multitask.LaunchHistoryStore
import com.sely.launcher.search.SearchActivity
import com.sely.launcher.sidebar.SidebarActivity
import com.sely.launcher.theme.ThemeManager

/**
 * Sely Home. This is the real HOME activity (see AndroidManifest's
 * category.HOME intent-filter) — selecting Sely Launcher as the default
 * launcher will bring the user here on every Home press.
 *
 * This foundation build wires up:
 *  - live app list from PackageManager (🟢 fully supported)
 *  - tap to launch, long-press for App info / Uninstall (🟢 official APIs)
 *  - dock of the first few apps as a stand-in for a configurable dock
 *
 * Not yet implemented (each is its own module per the project spec):
 * app drawer, control center, notification center, sidebar, gestures,
 * widgets, themes, Sely Transfer, etc. Build each as a separate Activity/
 * Fragment module under com.sely.launcher.<module> so this stays
 * maintainable as it grows.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var gestureListener: HomeGestureListener
    private lateinit var edgeGestureListener: EdgeGestureListener
    private lateinit var homeAdapter: AppGridAdapter
    private lateinit var dockAdapter: AppGridAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Start with empty lists so the Home Screen appears immediately.
        // Apps and icons are loaded on a background thread (see
        // refreshApps) instead of blocking the main thread.
        binding.homeGrid.layoutManager = GridLayoutManager(this, 4)
        homeAdapter = AppGridAdapter(this, emptyList())
        binding.homeGrid.adapter = homeAdapter

        binding.dock.layoutManager = GridLayoutManager(this, 5)
        dockAdapter = AppGridAdapter(this, emptyList())
        binding.dock.adapter = dockAdapter

        binding.searchBar.setOnClickListener {
            startActivity(Intent(this, SearchActivity::class.java))
        }

        binding.clockWidget.setOnClickListener {
            startActivity(Intent(this, com.sely.launcher.clock.ClockPickerActivity::class.java))
        }

        // Long-press empty home space -> Sely Theme (matches the common
        // launcher pattern of long-press-for-wallpaper-and-theme-options).
        binding.root.setOnLongClickListener {
            startActivity(Intent(this, com.sely.launcher.theme.ThemeActivity::class.java))
            true
        }

        // Swipe up anywhere on the home screen -> App Drawer.
        // Swipe down starting near the top edge -> Notification Center
        // (matches how status-bar shades work everywhere else).
        // Swipe down starting lower on the screen -> Control Center.
        val topEdgePx = resources.displayMetrics.density * 80
        gestureListener = HomeGestureListener(
            context = this,
            onSwipeUp = {
                com.sely.launcher.soundhaptics.SoundHapticsManager.onGesture(this)
                startActivity(Intent(this, AppDrawerActivity::class.java))
            },
            onSwipeDown = { startY ->
                com.sely.launcher.soundhaptics.SoundHapticsManager.onGesture(this)
                if (startY < topEdgePx) {
                    startActivity(Intent(this, NotificationCenterActivity::class.java))
                } else {
                    startActivity(Intent(this, ControlCenterActivity::class.java))
                }
            },
            onDoubleTap = { quickSwitch() }
        )

        // Swipe in from the right edge -> Sely Smart Sidebar.
        // (Left-edge swipe is detected too but unused for now — reserved
        // for a future "back"/quick-switch gesture.)
        edgeGestureListener = EdgeGestureListener(
            context = this,
            screenWidthPx = resources.displayMetrics.widthPixels,
            edgeWidthPx = (resources.displayMetrics.density * 24).toInt(),
            onEdgeSwipe = { fromRightEdge ->
                if (fromRightEdge) {
                    com.sely.launcher.soundhaptics.SoundHapticsManager.onGesture(this)
                    startActivity(Intent(this, SidebarActivity::class.java))
                }
            }
        )
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        gestureListener.detector.onTouchEvent(ev)
        edgeGestureListener.detector.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    // Sely Desktop Mode: real detection of a connected external display
    // via DisplayManager — only reliable while Home's process is alive,
    // which is normally the case for the active default launcher. See
    // DesktopModeLauncher/DesktopHomeActivity for what happens once one
    // is found.
    private val displayListener = object : android.hardware.display.DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) {
            if (displayId != android.view.Display.DEFAULT_DISPLAY) {
                android.widget.Toast.makeText(
                    this@MainActivity, "External display connected — open Desktop Mode from Settings", android.widget.Toast.LENGTH_LONG
                ).show()
            }
        }
        override fun onDisplayRemoved(displayId: Int) {}
        override fun onDisplayChanged(displayId: Int) {}
    }

    override fun onResume() {
        super.onResume()
        applyTheme()
        refreshApps()
        val displayManager = getSystemService(android.content.Context.DISPLAY_SERVICE) as android.hardware.display.DisplayManager
        displayManager.registerDisplayListener(displayListener, null)
    }

    override fun onPause() {
        super.onPause()
        val displayManager = getSystemService(android.content.Context.DISPLAY_SERVICE) as android.hardware.display.DisplayManager
        displayManager.unregisterDisplayListener(displayListener)
    }

    private var firstAppLoadDone = false

    /** Loads the app list off the main thread, then updates the grid + dock. */
    private fun refreshApps() {
        AppRepository.loadVisibleAppsAsync(this) { apps ->
            if (isFinishing || isDestroyed) return@loadVisibleAppsAsync
            homeAdapter.submit(apps)
            dockAdapter.submit(apps.take(5))
            if (!firstAppLoadDone) {
                firstAppLoadDone = true
                if (com.sely.launcher.performance.PerformanceModeStore.animationsEnabled(this)) {
                    binding.homeGrid.scheduleLayoutAnimation()
                }
            }
        }
    }

    /** Re-reads ThemeManager and re-skins Home — same pattern used by
     * every other screen (Drawer, Control Center, Sidebar, Theme picker). */
    private fun applyTheme() {
        binding.root.background = ThemeManager.homeScrim(this)
        ThemeManager.applyGlass(binding.searchBar, 26f)
        binding.searchBar.setTextColor(ThemeManager.textSecondary(this))
        ThemeManager.applyDock(binding.dock)
        homeAdapter.notifyDataSetChanged()
        dockAdapter.notifyDataSetChanged()

        val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        binding.homeGreeting.text = when {
            hour < 12 -> "Good morning"
            hour < 17 -> "Good afternoon"
            else -> "Good evening"
        }
        binding.homeGreeting.setTextColor(ThemeManager.textPrimary(this))

        val style = com.sely.launcher.clock.ClockPrefs.getStyle(this)
        binding.clockWidget.applyStyle(style, ThemeManager.textPrimary(this), ThemeManager.accentColor(this))
    }

    // Back press on Home should do nothing (standard launcher behavior),
    // not fall through to the previous app.
    override fun onBackPressed() {
        // intentionally empty
    }

    /** Sely Quick Switch (spec section 39) — see LaunchHistoryStore's doc
     * for why this uses Sely's own history rather than a system API. */
    private fun quickSwitch() {
        val target = LaunchHistoryStore.quickSwitchTarget(this)
        if (target == null) {
            android.widget.Toast.makeText(this, "Open at least two apps through Sely first", android.widget.Toast.LENGTH_SHORT).show()
            return
        }
        val (packageName, activityName) = target
        val app = AppRepository.resolveApp(this, packageName, activityName)
        if (app == null) {
            LaunchHistoryStore.removeFromHistory(this, packageName)
            android.widget.Toast.makeText(this, "That app is no longer installed", android.widget.Toast.LENGTH_SHORT).show()
            return
        }
        LaunchHistoryStore.recordLaunch(this, app.packageName, app.activityName)
        val intent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
            component = android.content.ComponentName(app.packageName, app.activityName)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        startActivity(intent)
    }
}
